
# Udacity Data Analyst Nanodegree
# Exploratory Data Analysis: What influences batter salaries?

## Introduction


[Sean Lahman's](http://www.seanlahman.com/baseball-archive/statistics/) baseball data data set contains complete batting and pitching statistics from 1871 to 2014, plus fielding statistics, standings, team stats, managerial records, post-season data, and more. The data set provides a variety of opportunities for statistically driven investigations.

This study aims to identify the variables and/or factors that  influence major league baseball player salaries. The study focuses strictly on batters, due to the inherent differences and roles between batters and pitchers.

## Report Sections

This report starts with a data wrangling phase involving data importing, merging and cleaning. Once prepped, the data is analyzed in the exploration phase and conclusions and suggestions for future studies are presented in the final section. 



# 1) Data Wrangling


```python
%load_ext autoreload
%autoreload 2
%matplotlib inline
```

    The autoreload extension is already loaded. To reload it, use:
      %reload_ext autoreload



```python
import general_utils as Ugen
import matplotlib.pyplot as plt
import pandas as pd
import math
from pandas.tools.plotting import scatter_matrix
import numpy as np
import seaborn as sns
from scipy import stats

sns.set(color_codes=True)
```


```python
#GET DATA
batter_df=pd.read_csv('baseballdata/Batting.csv') 
salary_df=pd.read_csv('baseballdata/Salaries.csv') 
```


```python
#EXPLORE DATA
batter_df.head() #print first 5 entries
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>playerID</th>
      <th>yearID</th>
      <th>stint</th>
      <th>teamID</th>
      <th>lgID</th>
      <th>G</th>
      <th>AB</th>
      <th>R</th>
      <th>H</th>
      <th>2B</th>
      <th>...</th>
      <th>RBI</th>
      <th>SB</th>
      <th>CS</th>
      <th>BB</th>
      <th>SO</th>
      <th>IBB</th>
      <th>HBP</th>
      <th>SH</th>
      <th>SF</th>
      <th>GIDP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>abercda01</td>
      <td>1871</td>
      <td>1</td>
      <td>TRO</td>
      <td>NaN</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>addybo01</td>
      <td>1871</td>
      <td>1</td>
      <td>RC1</td>
      <td>NaN</td>
      <td>25</td>
      <td>118</td>
      <td>30</td>
      <td>32</td>
      <td>6</td>
      <td>...</td>
      <td>13</td>
      <td>8</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>allisar01</td>
      <td>1871</td>
      <td>1</td>
      <td>CL1</td>
      <td>NaN</td>
      <td>29</td>
      <td>137</td>
      <td>28</td>
      <td>40</td>
      <td>4</td>
      <td>...</td>
      <td>19</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>allisdo01</td>
      <td>1871</td>
      <td>1</td>
      <td>WS3</td>
      <td>NaN</td>
      <td>27</td>
      <td>133</td>
      <td>28</td>
      <td>44</td>
      <td>10</td>
      <td>...</td>
      <td>27</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ansonca01</td>
      <td>1871</td>
      <td>1</td>
      <td>RC1</td>
      <td>NaN</td>
      <td>25</td>
      <td>120</td>
      <td>29</td>
      <td>39</td>
      <td>11</td>
      <td>...</td>
      <td>16</td>
      <td>6</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>




```python
#EXPLORE DATA
salary_df.head() #print first 5 entries
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>yearID</th>
      <th>teamID</th>
      <th>lgID</th>
      <th>playerID</th>
      <th>salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>barkele01</td>
      <td>870000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>bedrost01</td>
      <td>550000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>benedbr01</td>
      <td>545000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>campri01</td>
      <td>633333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>ceronri01</td>
      <td>625000</td>
    </tr>
  </tbody>
</table>
</div>



**Thoughts**: Right away, we can see that the salary data starts in 1985, whereas the batter data starts in 1871. Let's find out what range of years is covered in each data set.


```python
##FIND WHAT YEARS ARE COVERED
batter_years=list(batter_df['yearID'].values)
salary_years=list(salary_df['yearID'].values)

print ('batter_df covers %d-%d' % (min(batter_years),max(batter_years)))
print ('salary_df covers %d-%d' % (min(salary_years),max(salary_years)))

```

    batter_df covers 1871-2015
    salary_df covers 1985-2015



```python
#Clean up batters data table to eliminate years without salary data
batter_df=batter_df[batter_df['yearID']>=1985]

print (len(batter_df.index))
print (len(salary_df.index))
```

    39095
    25575


**Thoughts**: Looks like we are still limited by availability of salary data. Rather than filtering down the datasets until they match, it makes more sense to perform an inner join between the two datasets.


```python
##JOIN DATASETS
df=salary_df.merge(batter_df,'inner',['yearID','playerID','teamID'])

print(len(df.index))
df.head()
```

    24628





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>yearID</th>
      <th>teamID</th>
      <th>lgID_x</th>
      <th>playerID</th>
      <th>salary</th>
      <th>stint</th>
      <th>lgID_y</th>
      <th>G</th>
      <th>AB</th>
      <th>R</th>
      <th>...</th>
      <th>RBI</th>
      <th>SB</th>
      <th>CS</th>
      <th>BB</th>
      <th>SO</th>
      <th>IBB</th>
      <th>HBP</th>
      <th>SH</th>
      <th>SF</th>
      <th>GIDP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>barkele01</td>
      <td>870000</td>
      <td>1</td>
      <td>NL</td>
      <td>20</td>
      <td>17</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>bedrost01</td>
      <td>550000</td>
      <td>1</td>
      <td>NL</td>
      <td>37</td>
      <td>64</td>
      <td>3</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>benedbr01</td>
      <td>545000</td>
      <td>1</td>
      <td>NL</td>
      <td>70</td>
      <td>208</td>
      <td>12</td>
      <td>...</td>
      <td>20</td>
      <td>0</td>
      <td>1</td>
      <td>22</td>
      <td>12</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>2</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>campri01</td>
      <td>633333</td>
      <td>1</td>
      <td>NL</td>
      <td>66</td>
      <td>13</td>
      <td>1</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1985</td>
      <td>ATL</td>
      <td>NL</td>
      <td>ceronri01</td>
      <td>625000</td>
      <td>1</td>
      <td>NL</td>
      <td>96</td>
      <td>282</td>
      <td>15</td>
      <td>...</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
      <td>29</td>
      <td>25</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>4</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
##Investigate size reduction in df (from the original salary_df I was joining on)
players_1=df['playerID'].unique()
players_2=salary_df['playerID'].unique()

missing_players=[player for player in players_2 if player not in players_1]
len(missing_players)
```




    149



**Comments**: As can be seen, I lost some players in the inner join. My hypothesis is that these are players who never ended up playing and therefore didn't accumulate any stats.

**Missing Values**: Next, we check the data for missing values by running df.info()


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 24628 entries, 0 to 24627
    Data columns (total 24 columns):
    yearID      24628 non-null int64
    teamID      24628 non-null object
    lgID_x      24628 non-null object
    playerID    24628 non-null object
    salary      24628 non-null int64
    stint       24628 non-null int64
    lgID_y      24628 non-null object
    G           24628 non-null int64
    AB          22751 non-null float64
    R           22751 non-null float64
    H           22751 non-null float64
    2B          22751 non-null float64
    3B          22751 non-null float64
    HR          22751 non-null float64
    RBI         22751 non-null float64
    SB          22751 non-null float64
    CS          22751 non-null float64
    BB          22751 non-null float64
    SO          22751 non-null float64
    IBB         22751 non-null float64
    HBP         22751 non-null float64
    SH          22751 non-null float64
    SF          22751 non-null float64
    GIDP        22751 non-null float64
    dtypes: float64(16), int64(4), object(4)
    memory usage: 4.7+ MB


**Comments**: As shown above, all the variables after games (G) have a lower count than the other variables. This indicates that there are missing values present in these columns. This is investigated further below.


```python
##this statement prints any row (i.e. player record) with at least one missing values
print(len(df[df.isnull().any(axis=1)].index))
df[df.isnull().any(axis=1)].head()
```

    1877





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>yearID</th>
      <th>teamID</th>
      <th>lgID_x</th>
      <th>playerID</th>
      <th>salary</th>
      <th>stint</th>
      <th>lgID_y</th>
      <th>G</th>
      <th>AB</th>
      <th>R</th>
      <th>...</th>
      <th>RBI</th>
      <th>SB</th>
      <th>CS</th>
      <th>BB</th>
      <th>SO</th>
      <th>IBB</th>
      <th>HBP</th>
      <th>SH</th>
      <th>SF</th>
      <th>GIDP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23</th>
      <td>1985</td>
      <td>BAL</td>
      <td>AL</td>
      <td>davisst02</td>
      <td>437500</td>
      <td>1</td>
      <td>AL</td>
      <td>31</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1985</td>
      <td>BAL</td>
      <td>AL</td>
      <td>flanami01</td>
      <td>641667</td>
      <td>1</td>
      <td>AL</td>
      <td>15</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>31</th>
      <td>1985</td>
      <td>BAL</td>
      <td>AL</td>
      <td>martide01</td>
      <td>560000</td>
      <td>1</td>
      <td>AL</td>
      <td>33</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>32</th>
      <td>1985</td>
      <td>BAL</td>
      <td>AL</td>
      <td>martiti01</td>
      <td>440000</td>
      <td>1</td>
      <td>AL</td>
      <td>49</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1985</td>
      <td>BAL</td>
      <td>AL</td>
      <td>mcgresc01</td>
      <td>547143</td>
      <td>1</td>
      <td>AL</td>
      <td>35</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>



**Comments**: As shown above, there are 1877 player records that contain multiple missing values for variables such as AB, R, RBI etc. This is either due to the fact that these players never recorded any of these statistics, or the data itself is missing. Either way, these records with missing values will not be useful for analysis and may skew the results in some cases.

As a result, these records will be dropped and removed from any further analysis.


```python
##Get rid of rows with NaNs
df=df.dropna()
len(df)
```




    22751




```python
##Check if they were dropped
print(len(df[df.isnull().any(axis=1)].index))
df[df.isnull().any(axis=1)].head()
```

    0





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>yearID</th>
      <th>teamID</th>
      <th>lgID_x</th>
      <th>playerID</th>
      <th>salary</th>
      <th>stint</th>
      <th>lgID_y</th>
      <th>G</th>
      <th>AB</th>
      <th>R</th>
      <th>...</th>
      <th>RBI</th>
      <th>SB</th>
      <th>CS</th>
      <th>BB</th>
      <th>SO</th>
      <th>IBB</th>
      <th>HBP</th>
      <th>SH</th>
      <th>SF</th>
      <th>GIDP</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 24 columns</p>
</div>



Success!


```python
##Finally, get rid of any batter who never had an at-bat, or didn't have more than 20 at-bats
##This is done since players with so few plate appearances greatly skew the various batting statistics

print(len(df))
df=df[df['AB']>20]
len(df)
```

    22751





    14904



# 2) Data Exploration


```python
##One of the best ways to start is with the handy built-in pandas function; describe!
df.describe().round(0)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>yearID</th>
      <th>salary</th>
      <th>stint</th>
      <th>G</th>
      <th>AB</th>
      <th>R</th>
      <th>H</th>
      <th>2B</th>
      <th>3B</th>
      <th>HR</th>
      <th>RBI</th>
      <th>SB</th>
      <th>CS</th>
      <th>BB</th>
      <th>SO</th>
      <th>IBB</th>
      <th>HBP</th>
      <th>SH</th>
      <th>SF</th>
      <th>GIDP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
      <td>14904</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2000</td>
      <td>2355841</td>
      <td>1</td>
      <td>90</td>
      <td>284</td>
      <td>38</td>
      <td>75</td>
      <td>15</td>
      <td>2</td>
      <td>8</td>
      <td>37</td>
      <td>6</td>
      <td>2</td>
      <td>28</td>
      <td>52</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>6</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9</td>
      <td>3692685</td>
      <td>0</td>
      <td>47</td>
      <td>195</td>
      <td>32</td>
      <td>58</td>
      <td>12</td>
      <td>2</td>
      <td>10</td>
      <td>32</td>
      <td>9</td>
      <td>3</td>
      <td>25</td>
      <td>37</td>
      <td>4</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>6</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1985</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1993</td>
      <td>310000</td>
      <td>1</td>
      <td>42</td>
      <td>93</td>
      <td>10</td>
      <td>21</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2000</td>
      <td>700000</td>
      <td>1</td>
      <td>93</td>
      <td>261</td>
      <td>31</td>
      <td>65</td>
      <td>12</td>
      <td>1</td>
      <td>5</td>
      <td>29</td>
      <td>2</td>
      <td>1</td>
      <td>22</td>
      <td>44</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2008</td>
      <td>2800000</td>
      <td>1</td>
      <td>134</td>
      <td>461</td>
      <td>62</td>
      <td>123</td>
      <td>23</td>
      <td>2</td>
      <td>13</td>
      <td>57</td>
      <td>7</td>
      <td>3</td>
      <td>42</td>
      <td>76</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>10</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2015</td>
      <td>33000000</td>
      <td>3</td>
      <td>163</td>
      <td>716</td>
      <td>152</td>
      <td>262</td>
      <td>59</td>
      <td>23</td>
      <td>73</td>
      <td>165</td>
      <td>110</td>
      <td>29</td>
      <td>232</td>
      <td>223</td>
      <td>120</td>
      <td>35</td>
      <td>39</td>
      <td>17</td>
      <td>35</td>
    </tr>
  </tbody>
</table>
</div>



**Comments**: 

Describe returns a number of useful statistics, such as the count, mean, standard deviation, and quartiles. A few observations:

- Observing the count column gives us an indication of which columns are missing values and how many they are missing. All columns have the same number of values, indicating that the data wrangling was successful in eliminating values.

- Comparing the mean salary to the 50% & 75% percentiles shows that the mean has been heavily skewed by large salaries, since the mean is above the 75% percentile. This is further explored later on.


```python
def print_dis_stats(df,var):
    print('kurtosis: %s'% round(df[var].kurtosis(),2))
    print('skew: %s'% round(df[var].skew(),2))
```


```python
print_dis_stats(df,'salary')
sns.distplot(df['salary']);
```

    kurtosis: 9.47
    skew: 2.79



![png](output_27_1.png)


**Comments**: As expected, the salary distribution is highly skewed to the right, due to a small number of very large salaries. Since the data contains salaries from 1985-2015, it is possible that the data is slightly skewed by lower salaries from earlier years.


```python
df.plot(kind='scatter', x='yearID', y='salary',color='DarkBlue');
```


![png](output_29_0.png)


**Comments**: As shown above, salaries increase significantly over time. This is likely due to both inflation and higher team payrools. Unless these factors are adjusted for, salary data from earlier years cannot be used. 


```python
def percentile(n):
    def percentile_(x):
        return np.percentile(x, n)
    percentile_.__name__ = 'percentile_%s' % n
    return percentile_


##produce salary summary statistics for each year
yearly_df=df[df['yearID']>2000].groupby('yearID')['salary'].agg([sum,max,min,np.mean,percentile(25),np.median,percentile(75)])
yearly_df
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sum</th>
      <th>max</th>
      <th>min</th>
      <th>mean</th>
      <th>percentile_25</th>
      <th>median</th>
      <th>percentile_75</th>
    </tr>
    <tr>
      <th>yearID</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2001</th>
      <td>1338899774</td>
      <td>22000000</td>
      <td>200000</td>
      <td>2677799</td>
      <td>286875</td>
      <td>1100000</td>
      <td>4270833</td>
    </tr>
    <tr>
      <th>2002</th>
      <td>1378589448</td>
      <td>22000000</td>
      <td>200000</td>
      <td>2848325</td>
      <td>332500</td>
      <td>1150000</td>
      <td>4500000</td>
    </tr>
    <tr>
      <th>2003</th>
      <td>1478777028</td>
      <td>22000000</td>
      <td>165574</td>
      <td>3005644</td>
      <td>339375</td>
      <td>1000000</td>
      <td>4337500</td>
    </tr>
    <tr>
      <th>2004</th>
      <td>1431799823</td>
      <td>22500000</td>
      <td>300000</td>
      <td>2934016</td>
      <td>345000</td>
      <td>975000</td>
      <td>4016666</td>
    </tr>
    <tr>
      <th>2005</th>
      <td>1534925773</td>
      <td>26000000</td>
      <td>300000</td>
      <td>3191113</td>
      <td>365000</td>
      <td>1300000</td>
      <td>4312500</td>
    </tr>
    <tr>
      <th>2006</th>
      <td>1548780119</td>
      <td>21680727</td>
      <td>327000</td>
      <td>3295276</td>
      <td>374250</td>
      <td>1262500</td>
      <td>4458750</td>
    </tr>
    <tr>
      <th>2007</th>
      <td>1633184505</td>
      <td>23428571</td>
      <td>380000</td>
      <td>3460136</td>
      <td>400000</td>
      <td>1575000</td>
      <td>4756250</td>
    </tr>
    <tr>
      <th>2008</th>
      <td>1817076500</td>
      <td>28000000</td>
      <td>390000</td>
      <td>3833494</td>
      <td>411000</td>
      <td>1500000</td>
      <td>5500000</td>
    </tr>
    <tr>
      <th>2009</th>
      <td>1844379067</td>
      <td>33000000</td>
      <td>400000</td>
      <td>3974954</td>
      <td>435000</td>
      <td>1965625</td>
      <td>5925000</td>
    </tr>
    <tr>
      <th>2010</th>
      <td>1861237740</td>
      <td>33000000</td>
      <td>400000</td>
      <td>3960080</td>
      <td>430250</td>
      <td>1517838</td>
      <td>5487500</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>1911130437</td>
      <td>32000000</td>
      <td>414000</td>
      <td>3989833</td>
      <td>441250</td>
      <td>1625000</td>
      <td>5625000</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>2010560190</td>
      <td>30000000</td>
      <td>480000</td>
      <td>4162650</td>
      <td>495000</td>
      <td>1382500</td>
      <td>6037500</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>2055416064</td>
      <td>29000000</td>
      <td>480000</td>
      <td>4401319</td>
      <td>505000</td>
      <td>1955000</td>
      <td>6362500</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>2239603125</td>
      <td>26000000</td>
      <td>500000</td>
      <td>4656139</td>
      <td>515000</td>
      <td>2000000</td>
      <td>7000000</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>2368435326</td>
      <td>32571000</td>
      <td>507500</td>
      <td>5082479</td>
      <td>525443</td>
      <td>2500000</td>
      <td>7650000</td>
    </tr>
  </tbody>
</table>
</div>



The table above is useful for reference, however, the data can be used to produce more illustrative plots shown below.


```python
def df_plot(df,var,kind='line'):
    ax=df[var].plot(kind=kind);
    # format y-axis as currency
    vals = ax.get_yticks()
    ax.set_yticklabels(['${:,.0f}'.format(x) for x in vals]);
    return
```


```python
##Total league salaries per year
df_plot(yearly_df,'sum')
```


![png](output_34_0.png)



```python
##Average salary per year
df_plot(yearly_df,'mean')
```


![png](output_35_0.png)



```python
##Median salary over time
df_plot(yearly_df,'median')
```


![png](output_36_0.png)


**Comments**: Based on the three plots above, I chose to use the salary data from 2008-2011 for the remainder of the analysis, as the salary data was the most similiar among these years (based on the sum, mean and median).


```python
df=df[(df['yearID']>2007)&(df['yearID']<2012)]

print_dis_stats(df,'salary')
sns.distplot(df['salary']);
```

    kurtosis: 3.64
    skew: 1.84



![png](output_38_1.png)


**Comments**: While filtering did reduce both the skew and kurtosis of the salary distribution, it is still heavily skewed by large salaries.

To create a more normal distribution, the log of the salaries is taken.


```python
df['logsalary']=df.apply(lambda df: math.log10(df['salary']),axis=1)

print_dis_stats(df,'logsalary')
sns.distplot(df['logsalary']);
```

    kurtosis: -1.36
    skew: 0.26



![png](output_40_1.png)


Taking the log of the salaries reduces both the skewness and kurtosis significantly.

Next, I explore the impact of the league and the team on a player's salary.


```python
team_df=df.groupby('teamID')['salary'].agg([sum,max,min,np.mean,np.median])

df_plot(team_df,'median',kind='bar')
```


![png](output_42_0.png)


As shown in the chart above, some times clearly have much larger budgets and therefore pay their players signicantly more money. Noteworthy teams including the Boston Red Sox (BOS) and the Yankees (NYA).


```python
league_df=df.groupby('lgID_x')['salary'].agg([sum,max,min,np.mean,np.median,np.size])
print(league_df.head())
##plot the mean salary for each league across all years (2008-2011)
df_plot(league_df,'mean',kind='bar')
```

                   sum       max     min     mean   median  size
    lgID_x                                                      
    AL      3159799206  33000000  390000  4224330  2000000   748
    NL      4274024538  23854494  390000  3752435  1500000  1139



![png](output_44_1.png)


The plots above show that the AL league has a higher average salary. However, this must be taken with a grain of salt as the number of players from each league in the league_df is different, due to the constraints imposed during the data wrangling phase.

**Additional Stats**

Before exploring the relationships between the variables present in the table, additional statistics are computed.

- OBP (on-base percentage) = (Hits + Walks + Hit by Pitch) / (At Bats + Walks + Hit by Pitch + Sacrifice Flies)

- SLG (slugging percentage) = (1*1B + 2*2B + 3*3B + 4*HR)/AB 

- OPS (on-base plus slugging) = OBP + OPS

- BA (batting avg) = H/AB


```python
df['OBP']=(df['H']+df['BB']+df['IBB']+df['HBP'])/(df['AB']+df['BB']+df['IBB']+df['HBP']+df['SF'])
df['BA']=df['H']/df['AB']
df['1B']=df['H']-df['2B']-df['3B']-df['HR']
df['SLG']=(df['1B']+2*df['2B']+3*df['3B']+4*df['HR'])/df['AB']
df['OPS']=df['SLG']+df['OBP']
```


```python
##break up the variables for individual plotting

plot_vars_1=['logsalary','G','AB','R','H']
plot_vars_2=['logsalary','BA','OBP','SLG','OPS']

sns.pairplot(df,vars=plot_vars_1);
```


![png](output_48_0.png)


**Comments**

Pairplots are useful for exploring relationships between multiple variables, and the variable distributions themselves.

The top row shows the relationships between the log of the player's salaries and variables labelled along the bottom axis. Graphs along the diagonal axis show the distributions for each variable.

A few comments from the graphs:

- The feature variables follow a similarly skewed distribution to the salaries, with long right tails

- The feature variables themselves are highly correlated. This makes sense since a player's number of hits will be greatly influenced by the number of at-bats he has. Similarly, the number of games a player plays in will have a great influence on the number of AB's, hits, runs etc.

- Overall, the graphs with the logsalary variable are very noisy.

> For example, let's look at the graph of logsalary versus ABs. In the lower AB range, their is a large cluster of points that spans the entire range of salaries. Similarly, as the number of ABs increases, salaries do not necessarily increase for all players. Despite all the noise, the line of best fit for each logsalary plot would be positively sloped, based on visual inspection.

Next, we look to more advanced statistics and examine their trends.


```python
sns.pairplot(df,vars=plot_vars_2);
```


![png](output_50_0.png)


**Comments**

Similar observations are drawn for the second set of variables. The data is very noisy, and variables are highly correlated as expected. The variable distributions appear are more normal than the previous variables. 

Examining the top row logsalary plots, their appears to be some positive correlation between the advanced statistics and the salaries.

Next, variable correlations are examined graphically and numerically to determine the variables with the highest correlation to salary.


```python
# Make a dataframe with the selected features and the target variable
feature_vars=['G','AB','R','H','1B','2B','3B','HR','RBI','BB','IBB','BA','OBP','SLG','OPS']
df_final = df[feature_vars+['logsalary']] #select subset of columns

##Create a correlation heatmap
cor_mat = df_final.corr()
f, ax = plt.subplots(figsize=(15, 12))
# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(cor_mat,linewidths=.5, ax=ax);
```


![png](output_52_0.png)


The heatmap helps visually identify variables with high correlation. As shown by the axis, dark red indicates strong, positive correlations whereas dark blue indicates strong, negative correlations.

Examining the bottom row (logsalary), it appears that the correlations between logsalary and the different variables are generally very weak - especially when compared to the inter-variable correlations.

Based on the colours, it appears that runs batted in, home runs, and walks have the strongest correlation with salary.

This is explored further in the next cell.


```python
Y=df.logsalary 
X=df[feature_vars]

##compute pearson correlation coefficient, and associated p-value
corr_dict={feature:{'pearsonr': stats.pearsonr(X[feature].values,Y.values)[0],
                   'pval': stats.pearsonr(X[feature].values,Y.values)[1]} for feature in X.keys()}

corr_df=pd.DataFrame.from_dict(corr_dict,orient='index')
corr_df.sort_values('pearsonr',ascending=False)
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pearsonr</th>
      <th>pval</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>RBI</th>
      <td>0.280463</td>
      <td>1.904134e-35</td>
    </tr>
    <tr>
      <th>HR</th>
      <td>0.273048</td>
      <td>1.289743e-33</td>
    </tr>
    <tr>
      <th>IBB</th>
      <td>0.260371</td>
      <td>1.290842e-30</td>
    </tr>
    <tr>
      <th>BB</th>
      <td>0.259516</td>
      <td>2.030145e-30</td>
    </tr>
    <tr>
      <th>H</th>
      <td>0.233973</td>
      <td>7.027311e-25</td>
    </tr>
    <tr>
      <th>2B</th>
      <td>0.230069</td>
      <td>4.341918e-24</td>
    </tr>
    <tr>
      <th>R</th>
      <td>0.229637</td>
      <td>5.301416e-24</td>
    </tr>
    <tr>
      <th>AB</th>
      <td>0.228371</td>
      <td>9.488119e-24</td>
    </tr>
    <tr>
      <th>1B</th>
      <td>0.209339</td>
      <td>3.943135e-20</td>
    </tr>
    <tr>
      <th>G</th>
      <td>0.153790</td>
      <td>1.865898e-11</td>
    </tr>
    <tr>
      <th>SLG</th>
      <td>0.132671</td>
      <td>7.252744e-09</td>
    </tr>
    <tr>
      <th>OPS</th>
      <td>0.126745</td>
      <td>3.306278e-08</td>
    </tr>
    <tr>
      <th>OBP</th>
      <td>0.106447</td>
      <td>3.584531e-06</td>
    </tr>
    <tr>
      <th>BA</th>
      <td>0.097895</td>
      <td>2.045019e-05</td>
    </tr>
    <tr>
      <th>3B</th>
      <td>-0.035275</td>
      <td>1.255743e-01</td>
    </tr>
  </tbody>
</table>
</div>



# 3) Conclusions

**Final Discussion**

This study aimed to identify the variables that influenced a MLB batter's salary. 

Through an initial investigation of the underlying salary data, it was found that time has a significant impact on a player's salary, with salaries increasing significantly over time. This is believed to be due to both inflation and increasing team payrolls.

The effect of a player's team and league was explored next using bar charts. Certain teams, such as the New York Yankees and Boston Red Sox, had significantly higher median salaries, due to the absence of a salary cap in the MLB. There appeared to be a slight impact of a player's league on their salary, with the AL league having a higher mean and median salary than the NL. After futher investigation, it was identified that the two leagues had a different number of players in the data. As a result, the true impact of the league must be investigated with a full, un-filtered dataset.

Using a combination of scatter plots, heat maps, and pearson correlation coefficients, the factors with the highest correlation to batter salaries were identified. Using the table shown in the cell above, the variables with the highest correlation were RBIs, HRs and walks. All of these variables had very low p-values, indicating that the correlations are statistically significant. 

It is important to note that many of the trends discussed in this study are indeed correlations, and cannot be concluded as causal factors. In order to make such conclusions, strategies such as A/B testing would be required.

**Suggestions for Future Studies**

For future studies, it is recommended to incorporate additional data sources to investigate other variables. Data involving player's agents could indicate whether certain agents tend to get player's higher average salaries. Additionally, this study focused primarily on offensive batting statistics. More research should be done to determine which statistics best represent a player's defensive capabilities, and to quantify their effect on batter salaries.  


```python

```
